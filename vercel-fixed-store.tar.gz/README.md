# Multi Equipment Trade and Services

A responsive React / TypeScript medical equipment storefront using Next.js-compatible App Router APIs and Vinext, built for Cloudflare Workers / Sites. Tailwind CSS and reusable UI components are included. Structured records persist in Cloudflare D1.

## Vercel deployment

Set the Vercel project Root Directory to the directory containing this package.json (`store` if uploading the parent repository). Use the Next.js framework preset, `npm run build`, and `.next` output. The build runner automatically selects Next.js when Vercel sets `VERCEL=1`; Cloudflare/Sites builds continue to use Vinext. To verify locally in PowerShell, run `$env:VERCEL='1'; npm run build`.

Vercel does not provide the Cloudflare D1 binding or Sites authentication. The storefront can display its bundled catalog, but database-backed requests, reviews, catalog edits, and administrator access require a separate database and authentication integration. Until configured, database endpoints return their unavailable responses and administrator access is denied. Setting ADMIN_EMAILS alone does not enable Vercel administration.

## Local development

Use Node 22.13+ (Node 24 recommended). Run `npm install`, then `npm run dev`. Copy `.env.example` to `.env` if a canonical URL is needed. For local administrator access create an ignored `.dev.vars` containing `ADMIN_EMAILS=seedy@sites.test`; the portable preview uses that mock identity. Never configure the mock identity for production.

Apply the generated `drizzle/*.sql` migrations to the local D1 database before testing forms. The preview creates local state under `.wrangler/state/v3/d1`. The development server does not create schema at runtime. For deployment the Sites pipeline applies the Drizzle migrations automatically. `npm run db:generate` generates future migrations. Do not edit applied migrations.

Run `npx tsc --noEmit` for type checks and `npm run build` for the Worker build. `scripts/verify-local.mjs` checks local routes and form persistence using clearly identified test records; run only against the local preview.

## Environment and access

- `ADMIN_EMAILS`: comma-separated administrator email allowlist, configured as a Sites runtime environment variable. Blank denies all admin access. The server requires platform-authenticated identity headers and membership in this list. `/admin` starts platform Sign in with ChatGPT; no passwords or default production credentials are created.
- `SITE_URL`: documented canonical origin; replace the verified origin in route metadata, sitemap and robots if the deployment URL changes.
- `DB`: platform D1 binding, declared as `d1: "DB"` in `.openai/hosting.json`; this is not a secret connection string.

The initial deployment is private. Change sharing only after confirming business content and administrator access. Private Sites are for owner review, not a public customer launch.

## Data and business behavior

`lib/catalog.ts` contains the initial supplied product names and categories. Prices, technical details, SKUs and warranties remain unset. Admin edits persist in D1; the first product mutation initializes the editable catalog. Manufacturer photographs are remote references. The portable oxygen photograph is explicitly identified as a representative FreeStyle Comfort image. Confirm the actual supplied model and imagery before publishing business listings.

Orders, quotations, service requests, contact inquiries and reviews use the `requests` entity with a kind discriminator. Order items store a product/price snapshot. Models also include users, customers, addresses, carts, brands, categories, product images and specifications. The storefront cart is intentionally a device-local temporary selection. It is not the order source of truth.

Public forms validate fields, bound payload sizes, enforce same-origin browser submissions, use an atomic database-backed rate limit, and use idempotency keys. Submitted user text is rendered by React rather than HTML. Public reviews expose only name, rating and text after admin approval; customer contact details are not returned.

## Administration

Manage products, publish/unpublish, prices, availability, images, keywords, specifications, warranties and document links. View and update request statuses and internal notes. Review customer request history. Approve reviews before publication. Edit company contact details, hero text, business hours and policy text. Category/brand management stores taxonomy records; the starter navigation and brand filter choices remain predefined in `lib/catalog.ts` and should be synchronized when the taxonomy changes.

## Before public launch

Configure the real administrator email and test authorized administration. Confirm legitimate product supply, exact model photographs, brand usage and manufacturer documents. Complete verified product details and business policies. There are no fake prices, customer reviews, certifications or distributor claims. Policy text is a conservative editable baseline, not a claim that company policies have been legally finalized.

Checkout collects an order request, not payment or an automatically accepted sale. Price, delivery, taxes/discounts and payment are confirmed by the team. Customer self-service accounts and online order history are not enabled. Nepal payment gateways are not connected: add a server-side adapter with credential storage, signed webhook validation and payment-state reconciliation when an actual gateway and merchant account are selected. Do not put credentials in client code.

Image uploads, a complete multi-image gallery, granular inventory counts, automated notifications, promotional banner configuration and shipping/discount calculation are not implemented. Image/document URLs are editable. These limits must be resolved if required before calling the entire brief production-ready.

## Verification

TypeScript passes. The local checks cover 24 routes, quotation/service/contact/order/review persistence, duplicate prevention, validation and denied admin access. Browser checks cover desktop/mobile layout, search and no-results behavior, cart persistence and quantities. Browser WebMCP search handles valid SEFAM queries and rejects invalid input. Authorized admin CRUD needs the real administrator allowlist and a signed-in end-to-end check.

## October 7 content update

The supplied AirSep and CAIRE/SEFAM documents were used as product references, not instructions. Ten equipment listings and eight accessory/part inquiry listings are available, with document-supplied product photographs. No accessory prices, SKU numbers or compatibility claims were invented. The supplied product information includes the warranty and specifications now displayed; confirm the exact supplied configuration when quoting. No FAA or distributor-authorization claim was copied.

The public company details now use G.O.P. 8975, EPC 5222 and metsnepal.services@gmail.com. This public contact email does not grant admin access. The supplied screenshot is used through inline SVG viewports for its logo and illustrative hero imagery; the real interface is implemented in React. The logo gently animates and disables animation for users requesting reduced motion.
