'use client';
export default function Error({reset}:{reset:()=>void}){return <section className="wrap section empty"><h2>Something went wrong</h2><p>Please try again, or contact our team for assistance.</p><button className="btn" onClick={reset}>Try again</button></section>}
