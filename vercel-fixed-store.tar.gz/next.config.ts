import type { NextConfig } from "next";
import { resolve } from 'node:path';

const nextConfig: NextConfig = {
  turbopack: {
    resolveAlias: {
      '@/lib/runtime-env': './lib/runtime-env.vercel.ts',
    },
  },
  webpack(config, { webpack }) {
    config.plugins.push(new webpack.NormalModuleReplacementPlugin(
      /^@\/lib\/runtime-env$/,
      resolve(process.cwd(), 'lib/runtime-env.vercel.ts'),
    ));
    return config;
  },
};

export default nextConfig;
