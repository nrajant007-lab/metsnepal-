// Vercel has no Worker bindings or Sites-authenticated identity headers.
// Database routes retain their explicit unavailable responses until a database
// adapter is configured; never use ephemeral storage for customer submissions.
export const env: { DB?: D1Database; ADMIN_EMAILS?: string } = {};
