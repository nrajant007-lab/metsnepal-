import type {MetadataRoute} from 'next';
import {initialProducts} from '@/lib/catalog';
export default function sitemap():MetadataRoute.Sitemap{const base='https://multi-equipment-lalitpur-2026.bradleyjackson1.chatgpt.site';return ['','/products','/categories','/brands','/services','/service-request','/request-quote','/about','/contact',...initialProducts.map(p=>'/products/'+p.slug)].map(path=>({url:base+path,changeFrequency:'weekly'}))}
