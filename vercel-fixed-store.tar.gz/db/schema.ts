import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const products=sqliteTable('products',{id:text('id').primaryKey(),slug:text('slug').notNull().unique(),data:text('data').notNull(),published:integer('published').notNull().default(0)});
export const categories=sqliteTable('categories',{id:text('id').primaryKey(),name:text('name').notNull(),data:text('data').notNull()});
export const brands=sqliteTable('brands',{id:text('id').primaryKey(),name:text('name').notNull(),data:text('data').notNull()});
export const users=sqliteTable('users',{id:text('id').primaryKey(),email:text('email').unique(),role:text('role').notNull().default('customer')});
export const customers=sqliteTable('customers',{id:text('id').primaryKey(),phone:text('phone').notNull().unique(),data:text('data').notNull()});
export const requests=sqliteTable('requests',{id:text('id').primaryKey(),kind:text('kind').notNull(),customerId:text('customer_id').references(()=>customers.id),data:text('data').notNull(),status:text('status').notNull().default('Pending'),notes:text('notes').notNull().default(''),createdAt:text('created_at').notNull(),idempotencyKey:text('idempotency_key').notNull().unique()},t=>[index('idx_requests_kind_created').on(t.kind,t.createdAt)]);
export const orderItems=sqliteTable('order_items',{id:text('id').primaryKey(),orderId:text('order_id').notNull().references(()=>requests.id),productId:text('product_id').notNull(),quantity:integer('quantity').notNull(),unitPrice:integer('unit_price'),snapshot:text('snapshot').notNull()});
export const productImages=sqliteTable('product_images',{id:text('id').primaryKey(),productId:text('product_id').notNull().references(()=>products.id),url:text('url').notNull(),alt:text('alt')});
export const productSpecifications=sqliteTable('product_specifications',{id:text('id').primaryKey(),productId:text('product_id').notNull().references(()=>products.id),name:text('name').notNull(),value:text('value').notNull()});
export const carts=sqliteTable('carts',{id:text('id').primaryKey(),userId:text('user_id').references(()=>users.id),data:text('data').notNull()});
export const addresses=sqliteTable('addresses',{id:text('id').primaryKey(),customerId:text('customer_id').references(()=>customers.id),data:text('data').notNull()});
export const settings=sqliteTable('settings',{id:text('id').primaryKey(),data:text('data').notNull()});
export const rateLimits=sqliteTable('rate_limits',{key:text('key').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()});
// Orders, quotations, service requests, contact inquiries and moderated reviews share the requests table, discriminated by kind.
