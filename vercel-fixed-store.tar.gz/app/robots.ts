import type {MetadataRoute} from 'next';
export default function robots():MetadataRoute.Robots{return {rules:{userAgent:'*',allow:'/',disallow:['/admin','/api','/checkout','/account']},sitemap:'https://multi-equipment-lalitpur-2026.bradleyjackson1.chatgpt.site/sitemap.xml'}}
