import {catalog} from '@/lib/server';
export async function GET(){try{return Response.json(await catalog(),{headers:{'Cache-Control':'no-store'}})}catch(e){console.error('Catalog read failed',e);return Response.json({error:'Catalog updates are temporarily unavailable.'},{status:503})}}
