import Store from '../store';
import type {Metadata} from 'next';
import {catalog} from '@/lib/server';
import {initialProducts} from '@/lib/catalog';
const origin='https://multi-equipment-lalitpur-2026.bradleyjackson1.chatgpt.site';
export async function generateMetadata({params}:{params:Promise<{slug:string[]}>}):Promise<Metadata>{const {slug}=await params;let products=initialProducts;try{products=(await catalog()).products}catch{}const p=products.find(p=>p.slug===slug.at(-1)&&p.published);const label=p?.name||slug.at(-1)!.replaceAll('-',' ');return {title:`${label} | Multi Equipment Nepal`,description:p?.description||'Medical equipment supply, sales and repair support in Lalitpur, Nepal.',alternates:{canonical:origin+'/'+slug.join('/')},openGraph:{title:label,description:p?.description||'Medical equipment supply and service in Nepal.'}}}
export default async function Page({params}:{params:Promise<{slug:string[]}>}){const {slug}=await params;return <Store path={'/'+slug.join('/')}/>}
